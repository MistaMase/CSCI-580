# Name: John (JJ) Mase
# USC ID: 6904908117
# Email: mase@usc.edu
# Visual Studio Version: 16.11.0
# Other Information
## Procedural Textures
I've added two different procedudral textures, a checkerboard and Sierpinski carpet. Both run through the ptex_fun function pointer, except a compiler directive can be toggled within ptex_fun within tex_fun.cpp. To run the checkerboard texture, simply change the ```#if X``` value to ```#if 0```. To run the Sierpinski carpet, simply change the ```#if X``` value to ```#if 1```.