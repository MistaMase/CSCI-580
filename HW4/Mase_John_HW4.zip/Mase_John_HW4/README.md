# Name: John (JJ) Mase
# USC ID: 6904908117
# Email: mase@usc.edu
# Visual Studio Version: 16.11.0
# Other Information
## Helper Functions and Member Variables
For this assignment, I've highly modularized my code, hopefully for future assignments. Accordingly, there's many new helper functions that are all named pretty logically and should make sense by just reading them. These new helper functions and member variables are, of course, defined as private so anyone outside the scope of the project can't use them. The function declarations can be found in rend.h, if necessary, and their implementations can be found at the bottom of rend.cpp

## Regrading
No regrading is needed as all previous assignments had perfect marks.